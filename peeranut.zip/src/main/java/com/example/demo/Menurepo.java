package com.example.demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RestController;

@Repository
public class Menurepo {
	@PersistenceContext
	private EntityManager em;
	
	public List<Menus> findAll() {
		Query query = em.createQuery("from Menus");
		return query.getResultList();
	}
	
	public Menus findById(Integer id){
		return em.find(Menus.class, id);
	}
	
	@Transactional
	public Menus save(Menus m) {
		em.persist(m);
		return m;
	}
	
	@Transactional
	public void delete(Menus m) {
		em.remove(m);
	}

}
