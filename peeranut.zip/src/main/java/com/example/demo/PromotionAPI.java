package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*" , allowedHeaders = "*")
@RestController
public class PromotionAPI {
	@Autowired
	Promotionrepo prepo;
	
	@GetMapping("/promotions")
	public List<Promotion> getpromotion(){
		return prepo.findAll();
	}
	
	@GetMapping("/promotion/{id}")
	public Promotion getpromotion(@PathVariable("id") Integer  id) {
		return prepo.findById(id);
	}
	
	@PostMapping("/promotion")
	public String insertpromotion(@RequestBody Promotion p) {
		prepo.save(p);
		return "ADD success";
	}
	@DeleteMapping("/promotion/{id}")
	public String removepromotion(@PathVariable("id") Integer id) {
		prepo.delete(prepo.findById(id));
		return "DELETE Success";
	}
	@PutMapping("/promotion")
	public String editpromotion(@RequestBody Promotion p) {
		Promotion  text = prepo.findById(p.getpId());
		text.setpName(p.getpName());
		text.setpDetail(p.getpDetail());
		text.setpImage(p.getpImage());
		prepo.save(text);
		return "EDIT Success";
	}
}
