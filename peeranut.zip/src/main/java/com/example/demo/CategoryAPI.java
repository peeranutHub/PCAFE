package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CategoryAPI {
	@Autowired
	Categoryrepo carepo;
	
	@GetMapping("/categorys")
	public List<Category> getCategory(){
		return carepo.findAll();
	}
	
	@GetMapping("/category/{id}")
	public Category getCategory(@PathVariable("id") int  ide) {
		return carepo.findById(ide);
	}
	
	@PostMapping("/category")
	public String insertCategory(@RequestBody Category f) {
		carepo.save(f);
		return "ADD success";
	}
	
	@DeleteMapping("/category/{id}")
	public String removeCategory(@PathVariable("id") Integer id) {
		carepo.delete(carepo.findById(id));
		return "DELETE Success";
	}
	@PutMapping("/category")
	public String editCategory(@RequestBody Category c) {
		Category text = carepo.findById(c.getCaId());
		text.setCaName(c.getCaName());
		carepo.save(text);
		return "EDIT Success";
	}
}