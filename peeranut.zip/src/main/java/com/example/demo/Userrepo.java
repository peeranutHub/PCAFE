package com.example.demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RestController;

@Repository
public class Userrepo {
	@PersistenceContext
	private EntityManager em;
	
	public List<Users> findAll() {
		Query query = em.createQuery("from Users");
		return query.getResultList();
	}
	
	public Users findById(Integer id){
		return em.find(Users.class, id);
	}
	
	@Transactional
	public Users save(Users u) {
		em.persist(u);
		return u;
	}
	
	@Transactional
	public void delete(Users u) {
		em.remove(u);
	}

}
