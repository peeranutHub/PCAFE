package com.example.demo;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Category {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer caId;
	private String caName;
	
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "category")
	private List<Menus> Menu;
	
	public Integer getCaId() {
		return caId;
	}
	public void setCaId(Integer caId) {
		this.caId = caId;
	}
	public String getCaName() {
		return caName;
	}
	public void setCaName(String caName) {
		this.caName = caName;
	}
	
	@JsonManagedReference
	public List<Menus> getMenu() {
		return Menu;
	}
	public void setMenu(List<Menus> menu) {
		Menu = menu;
	}
	
	

}
