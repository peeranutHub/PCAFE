	package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Menus {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer mId;
	private String mName;
	private Integer mPrice;
	private String mDetail;
	private String mImage;
	
	@ManyToOne
	@JoinColumn(name="caId", nullable=false)
	private Category category;
	
	public Integer getmId() {
		return mId;
	}
	public void setmId(Integer mId) {
		this.mId = mId;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public Integer getmPrice() {
		return mPrice;
	}
	public void setmPrice(Integer mPrice) {
		this.mPrice = mPrice;
	}
	public String getmDetail() {
		return mDetail;
	}
	public void setmDetail(String mDetail) {
		this.mDetail = mDetail;
	}
	public String getmImage() {
		return mImage;
	}
	public void setmImage(String mImage) {
		this.mImage = mImage;
	}
	
	@JsonBackReference
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	
	

}
