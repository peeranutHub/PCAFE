package com.example.demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RestController;

@Repository
public class Promotionrepo {
	@PersistenceContext
	private EntityManager em;
	
	public List<Promotion> findAll() {
		Query query = em.createQuery("from Promotion");
		return query.getResultList();
	}
	
	public Promotion findById(Integer id){
		return em.find(Promotion.class, id);
	}
	
	@Transactional
	public Promotion save(Promotion p) {
		em.persist(p);
		return p;
	}
	
	@Transactional
	public void delete(Promotion p) {
		em.remove(p);
	}

}
