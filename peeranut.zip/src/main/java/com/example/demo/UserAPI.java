package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class UserAPI {
	@Autowired
	Userrepo urepo;
	
	@GetMapping("/users")
	public List<Users> getUsers(){
		return urepo.findAll();
	}
	
	@GetMapping("/user/{id}")
	public Users getUser(@PathVariable("id") Integer  id) {
		return urepo.findById(id);
	}
	
	@PostMapping("/user")
	public String insertUser(@RequestBody Users u) {
		urepo.save(u);
		return "ADD success";
	}
	@DeleteMapping("/user/{id}")
	public String removeUser(@PathVariable("id") Integer id) {
		urepo.delete(urepo.findById(id));
		return "DELETE Success";
	}
	@PutMapping("/user")
	public String editUser(@RequestBody Users u) {
		Users  text = urepo.findById(u.getuId());
		text.setuName(u.getuName());
		text.setuImage(u.getuImage());
		urepo.save(text);
		return "EDIT Success";
	}
	@PutMapping("/user/{id}")
	public String editPoint(@PathVariable("id") Integer id) {
		Users p =  urepo.findById(id);
		Integer newpoint = p.getuPoint()+1;
		p.setuPoint(newpoint);
		urepo.save(p);
		return "Plus Success " + p.getuPoint();
	}
	
	@PutMapping("/users/{id}")
	public String decreasePoint(@PathVariable("id") Integer id) {
		Users p =  urepo.findById(id);
		if(p.getuPoint() >= 1) {	
		Integer newpoint = p.getuPoint()-1;
		p.setuPoint(newpoint);
		}
		urepo.save(p);
		return "Decrease Success "+p.getuPoint();
	}
}
