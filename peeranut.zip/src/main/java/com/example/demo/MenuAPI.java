package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*" , allowedHeaders = "*")
@RestController
public class MenuAPI {
	@Autowired
	Menurepo mrepo;
	
	@GetMapping("/menus")
	public List<Menus> getUser(){
		return mrepo.findAll();
	}
	
	@GetMapping("/menu/{id}")
	public Menus getMenu(@PathVariable("id") Integer  id) {
		return mrepo.findById(id);
	}
	
	@PostMapping("/menu")
	public String insertMenu(@RequestBody Menus m) {
		mrepo.save(m);
		return "ADD success";
	}
	@DeleteMapping("/menu/{id}")
	public String removeMenu(@PathVariable("id") Integer id) {
		mrepo.delete(mrepo.findById(id));
		return "DELETE Success";
	}
	@PutMapping("/menu")
	public String editMenu(@RequestBody Menus m) {
		Menus  text = mrepo.findById(m.getmId());
		text.setmName(m.getmName());
		text.setmPrice(m.getmPrice());
		text.setmDetail(m.getmDetail());
		text.setmImage(m.getmImage());
		text.setCategory(m.getCategory());
		mrepo.save(text);
		return "EDIT Success";
	}
}
